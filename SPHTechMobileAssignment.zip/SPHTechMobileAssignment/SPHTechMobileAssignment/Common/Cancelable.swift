//
//  Cancelable.swift
//  SPHTechMobileAssignment
//
//  Created by Jingmeng.Gan on 6/9/19.
//  Copyright © 2019 Jingmeng.Gan. All rights reserved.
//

import Foundation
public protocol Cancellable {
    func cancel()
}
